
// Simple script to fill enquiry message and open mailto or WhatsApp
document.addEventListener('DOMContentLoaded', function(){
  const form = document.getElementById('enquiryForm');
  const waBtn = document.getElementById('waSend');
  const buttons = document.querySelectorAll('.enquire-btn');
  const messageField = document.getElementById('message');

  // When clicking a product Enquire button, fill message
  buttons.forEach(b=>{
    b.addEventListener('click', ()=>{
      const prod = b.dataset.prod || 'Product';
      messageField.value = `Enquiry for: ${prod}\n\nPlease provide price, availability & delivery details.`;
      window.location.hash = '#contact';
      messageField.focus();
    });
  });

  form.addEventListener('submit', function(e){
    e.preventDefault();
    const data = new FormData(form);
    const name = data.get('name') || '';
    const phone = data.get('phone') || '';
    const email = data.get('email') || '';
    const message = data.get('message') || '';
    const subject = encodeURIComponent('Enquiry from website - Chinna Furniture');
    const body = encodeURIComponent(`Name: ${name}%0APhone: ${phone}%0AEmail: ${email}%0A%0AMessage:%0A${message}`);
    // mailto
    const mailto = `mailto:chinna.furniture@example.com?subject=${subject}&body=${body}`;
    window.location.href = mailto;
  });

  waBtn.addEventListener('click', function(){
    const data = new FormData(form);
    const name = data.get('name') || '';
    const phone = data.get('phone') || '';
    const message = data.get('message') || '';
    const text = encodeURIComponent(`Enquiry from website%0AName: ${name}%0APhone: ${phone}%0A%0A${message}`);
    // change number if needed
    const waUrl = `https://wa.me/918019714828?text=${text}`;
    window.open(waUrl, '_blank');
  });
});
